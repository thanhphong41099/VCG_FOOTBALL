﻿1. Nên cài đặt app ở ổ D:\UptopCGControl

2. Cấu hình lại WorkingFolder và file Database khi cài khác ổ D:\UptopCGControl

3. Nên để giao diện sử dụng ở display resolution 1920x1080, scale 100%

4.Nếu cài app ở ổ C, file config.cfg thêm quyền user full control


